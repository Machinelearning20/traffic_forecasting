import numpy as np
import torch
import torch.optim as optim
from torch import nn
from time import time

from lib.metrics import masked_mae, masked_rmse, masked_mape
from lib.metrics import metric


class Trainer:
    def __init__(self, model, scaler, device, **optim_args):
        self.model = model  # init model
        self.output_seq_len = 12
        self.print_model_structure = True

        self.scaler = scaler
        self.device = device

        # training strategy parameters
        self.lrate = optim_args['lrate']
        self.wdecay = optim_args['wdecay']
        self.eps = 1.0e-8

        # learning rate scheduler
        self.if_lr_scheduler = optim_args['if_lr_scheduler']
        if self.if_lr_scheduler:
            self.lr_sche_steps = optim_args['lr_steps']
            self.lr_decay_ratio = optim_args['lr_decay_ratio']

        # Adam optimizer
        self.optimizer = optim.AdamW(self.model.parameters(), lr=self.lrate, weight_decay=self.wdecay)

        # learning rate scheduler
        self.lr_scheduler = torch.optim.lr_scheduler.MultiStepLR(self.optimizer, milestones=self.lr_sche_steps,
                                                                 gamma=self.lr_decay_ratio) if self.if_lr_scheduler else None

        # loss
        self.loss = masked_mae
        self.clip = optim_args['clip_grad']  # gradient clip

    def reset_lr_model(self, args):
        if args.start_epoch == 0:
            return
        else:
            checkpoint = torch.load(f'cpt/{args.dataset}/best_model_epoch{args.start_epoch}.pth')
            self.model.load_state_dict(checkpoint['model_state_dict'])
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            if self.lr_scheduler is not None:
                self.lr_scheduler.load_state_dict(checkpoint['lr_scheduler_state_dict'])

    def print_model(self, logger):
        logger.info(self.model)

    def train_batch(self, x, real_val, **kwargs):
        self.model.train()
        self.optimizer.zero_grad()

        x[..., 0] = self.scaler.transform(x[..., 0])
        output = self.model(x, kwargs['epoch'])  # (B, T, N, F)

        output = self.scaler.inverse_transform(output)
        mae_loss = self.loss(output, real_val, torch.tensor(0.0).to(self.device))

        loss = mae_loss
        loss.backward()

        # gradient clip and optimization
        if self.clip is not None:
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip)
        self.optimizer.step()

        # metrics
        mape = masked_mape(output, real_val, torch.tensor(0.0).to(self.device))
        rmse = masked_rmse(output, real_val, torch.tensor(0.0).to(self.device))
        return mae_loss.item(), mape.item(), rmse.item()

    def train(self, train_loader, **kwargs):
        self.model.train()
        train_loss = []
        train_mape = []
        train_rmse = []

        for x, y in train_loader:
            x, y = x.to(self.device), y.to(self.device)
            mae_loss, mape, rmse = self.train_batch(x, y, **kwargs)
            train_loss.append(mae_loss)
            train_mape.append(mape)
            train_rmse.append(rmse)

        mean_loss = np.mean(train_loss)
        mean_mape = np.mean(train_mape)
        mean_rmse = np.mean(train_rmse)

        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

        return mean_loss, mean_mape, mean_rmse

    def eval(self, val_loader):
        # val a epoch
        valid_loss = []
        valid_mape = []
        valid_rmse = []
        with torch.no_grad():
            self.model.eval()
            for x, real_val in val_loader:
                x, real_val = x.to(self.device), real_val.to(self.device)

                x[..., 0] = self.scaler.transform(x[..., 0])
                output = self.model(x)  # (B, T, N, F)
                output = self.scaler.inverse_transform(output)

                mae, rmse, mape = metric(output.cpu().numpy(), real_val.cpu().numpy())

                # print("test: {0}".format(loss), end='\r')

                valid_loss.append(mae)
                valid_mape.append(mape)
                valid_rmse.append(rmse)

        mvalid_loss = np.mean(valid_loss)
        mvalid_mape = np.mean(valid_mape)
        mvalid_rmse = np.mean(valid_rmse)

        return mvalid_loss, mvalid_mape, mvalid_rmse

    def test(self, data_loader, epoch, logger):
        self.model.train(False)  # ensure dropout layers are in test mode

        with torch.no_grad():
            prediction = []  # 存储所有batch的output
            data_target = []

            start_time = time()
            for x, real_val in data_loader:
                x, real_val = x.to(self.device), real_val.to(self.device)

                x[..., 0] = self.scaler.transform(x[..., 0])
                output = self.model(x)
                output = self.scaler.inverse_transform(output)

                prediction.append(output.detach().cpu().numpy())
                data_target.append(real_val.detach().cpu().numpy())

            end_time = time()
            prediction = np.concatenate(prediction, 0)  # (batch, T', 1)
            data_target = np.concatenate(data_target, 0)

            prediction_length = prediction.shape[1]

            mask_value = torch.tensor(0).to(self.device)

            for i in range(prediction_length):
                mae, rmse , mape = metric(prediction[:,i,:], data_target[:,i,:])
                logger.info('predict %s-th point  MAE: %.6f, RMSE: %.6f, MAPE: %.6f' % (i+1, mae, rmse, mape))

            # print overall results
            mae, rmse, mape = metric(prediction, data_target)
            logger.info('test cost time: %.4fs all MAE: %.4f, all RMSE: %.4f, all MAPE: %.4f' % (end_time - start_time, mae, rmse, mape))
