import matplotlib.pyplot as plt
import numpy as np

# 原始数据（不等距）
original_x = np.array([20, 30, 40, 50])
mae_values = np.array([16.2863, 16.1559, 16.2510, 16.1872])
rmse_values = np.array([28.1510, 27.9699, 28.0836, 28.0251])

# 等距的绘图位置（例如 0,1,2,3）
plot_positions = np.arange(len(original_x))  # [0,1,2,3]

fig, ax1 = plt.subplots(figsize=(4.5, 3.5))

# 左轴 MAE（使用等距位置绘图）
line1, = ax1.plot(plot_positions, mae_values,
                   color='#004F60', linestyle='-', marker='o', markersize=5,
                   label='MAE')
ax1.set_ylabel('MAE', color='#004F60', fontsize=18)

# 右轴 MAPE（同样使用等距位置）
ax2 = ax1.twinx()
line2, = ax2.plot(plot_positions, rmse_values,
                   color='#5DADE2', linestyle='-', marker='o', markersize=5,  # 深青灰色
                   label='RMSE')
ax2.set_ylabel('RMSE', color='#5DADE2', fontsize=18)
ax2.tick_params(axis='y', labelcolor='#5DADE2')

# 设置 x 轴：等距位置 + 原始数值标签
ax1.set_xticks(plot_positions)                # 刻度位置为 0,1,2,3
ax1.set_xticklabels(original_x)               # 标签显示 32,64,128,256
ax1.set_xlabel('K on CA', fontsize=16) # <L or M or K> on <dataset_name>
ax1.tick_params(axis='x')

ax1.tick_params(axis='both', labelsize=13)
ax1.yaxis.set_major_formatter(StrMethodFormatter('{x:.2f}'))
ax1.yaxis.set_major_locator(LinearLocator(numticks=4))

ax2.tick_params(axis='both', labelsize=13)
ax2.yaxis.set_major_formatter(StrMethodFormatter('{x:.2f}'))
ax2.yaxis.set_major_locator(LinearLocator(numticks=4))

# 图例（放在图内右上角）
ax1.legend([line1, line2], ['MAE', 'RMSE'],
           loc='upper right', frameon=False, fontsize=15)  # 调整loc参数，使得折线与图例不重合，不同的图不一样

plt.tight_layout()
plt.subplots_adjust(bottom=0.15)
plt.show()


'''
SD - 层数超参研究

original_x = np.array([3, 4, 5, 6])
mae_values = np.array([15.9431, 16.0091, 15.9919, 15.9832])
rmse_values = np.array([27.2726, 27.4346, 27.3309, 27.3868])


SD - 超边数超参研究

original_x = np.array([16, 32, 64, 128])
mae_values = np.array([15.8852, 15.9431, 15.8853, 15.9556])
rmse_values = np.array([27.1170, 27.2726, 27.1534, 27.2360])


SD - K超参研究

original_x = np.array([4, 6, 8, 10])
mae_values = np.array([16.0818, 16.1296, 15.9059, 15.8852])
rmse_values = np.array([27.4305, 27.5099, 27.1415, 27.1170])


GBA - 层数超参研究

original_x = np.array([3, 4, 5, 6])
mae_values = np.array([18.1905, 18.1339, 18.3039, 18.1006])
rmse_values = np.array([31.3101, 31.2299, 31.6318, 31.3236])


GBA - 超边数超参研究

original_x = np.array([32, 64, 128, 256])
mae_values = np.array([18.2824, 18.1768, 18.1006, 18.1507])
rmse_values = np.array([31.5695, 31.4098, 31.3236, 31.4529])


GBA - K超参研究

original_x = np.array([10, 20, 30, 40])
mae_values = np.array([18.1451, 18.1535, 18.1006, 18.1648])
rmse_values = np.array([31.4720, 31.3808, 31.3236, 31.4050])


GLA - 层数超参研究

original_x = np.array([3, 4, 5, 6])
mae_values = np.array([17.7703, 17.5563, 17.5581, 17.5748])
rmse_values = np.array([30.0709, 29.7395, 29.8689, 29.9042])


GLA - 超边数超参研究

original_x = np.array([32, 64, 128, 256])
mae_values = np.array([17.6042, 17.6468, 17.5581, 17.4773])
rmse_values = np.array([29.8887, 29.9849, 29.8689, 29.7441])


GLA - K超参研究

original_x = np.array([10, 20, 30, 40])
mae_values = np.array([17.5707, 17.4773, 17.5865, 17.6396])
rmse_values = np.array([29.8650, 29.7441, 29.8623, 29.9360])


CA - 层数超参研究

original_x = np.array([3, 4, 5, 6])
mae_values = np.array([16.3431, 16.3830, 16.2656, 16.1559])
rmse_values = np.array([28.1220, 28.1831, 28.0591, 27.9699])


CA - 超边数超参研究

original_x = np.array([64, 128, 256, 512])
mae_values = np.array([16.2173, 16.2861, 16.4048, 16.1559])
rmse_values = np.array([28.0881, 28.1953, 28.3413, 27.9699])


CA - K超参研究

original_x = np.array([20, 30, 40, 50])
mae_values = np.array([16.2863, 16.1559, 16.2510, 16.1872])
rmse_values = np.array([28.1510, 27.9699, 28.0836, 28.0251])

'''