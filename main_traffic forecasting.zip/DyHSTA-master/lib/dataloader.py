import torch
import numpy as np
import pandas as pd
from collections import deque

from torch.utils.data import Dataset, DataLoader


class TSDataset(Dataset):
    def __init__(self, data, seq_len, horizon, stride=1):
        super().__init__()
        self.data = data
        self.seq_len = seq_len
        self.horizon = horizon
        self.stride = stride

        total = data.shape[0]
        self.num_samples = max(0, (total - (seq_len + horizon)) // stride + 1)

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        t = idx * self.stride
        x = self.data[t : t + self.seq_len]
        y = self.data[t + self.seq_len : t + self.seq_len + self.horizon, :, :1]
        return (
            torch.from_numpy(x.copy()).float(),
            torch.from_numpy(y.copy()).float(),
        )


class StandardScaler:
    def __init__(self, mean, std):
        self.mean = torch.tensor(mean)
        self.std = torch.tensor(std)

    def transform(self, data):
        return (data - self.mean) / self.std

    def inverse_transform(self, data):
        return (data * self.std) + self.mean


def read_meta(path):
    meta = pd.read_csv(path)
    lat = meta['Lat'].values
    lng = meta['Lng'].values
    locations = np.stack([lat,lng], 0)
    return locations


def kdTree(locations, times, axis):
    # locations: [2,N] contains lng and lat
    # times: depth of kdtree
    # axis: select lng or lat as hyperplane to split points
    sorted_idx = np.argsort(locations[axis])
    part1, part2 = np.sort(sorted_idx[:locations.shape[1]//2]), np.sort(sorted_idx[locations.shape[1]//2:])
    parts = []
    if times == 1:
        return [part1, part2], max(part1.shape[0], part2.shape[0])
    else:
        left_parts, lmxlen = kdTree(locations[:,part1], times-1, axis^1)
        right_parts, rmxlen = kdTree(locations[:,part2], times-1, axis^1)
        for part in left_parts:
            parts.append(part1[part])
        for part in right_parts:
            parts.append(part2[part])
    return parts, max(lmxlen, rmxlen)


def kdtree_hyperedge(metapath, depth=11, factors=16):
    # SD 9 32
    # GBA 11 32
    # GLA 11 32
    # CA 12 8
    locations = read_meta(metapath)
    parts_idx, mx_len = kdTree(locations, depth, 0)

    patches = [
        [node for part in parts_idx[i:i + factors] for node in part]
        for i in range(0, len(parts_idx), factors)
    ]

    num_patches = len(patches)
    hyperedge = np.zeros((num_patches, locations.shape[1]), dtype=np.float32)
    for p_idx, node_indices in enumerate(patches):
        hyperedge[p_idx, node_indices] = 1.0
    return hyperedge


def agglomerative_clustering_hyperedge(metapath, n_clusters=32):
    from sklearn.metrics.pairwise import haversine_distances
    from sklearn.cluster import AgglomerativeClustering

    coords = read_meta(metapath).T

    coords_rad = np.radians(coords)
    dist_matrix = haversine_distances(coords_rad) * 6371

    model = AgglomerativeClustering(
        n_clusters=n_clusters,
        distance_threshold=None,
        metric="precomputed",
        linkage="average"
    )

    labels = model.fit_predict(dist_matrix)
    unique, counts = np.unique(labels, return_counts=True)
    hyperedge = np.zeros((len(counts), coords.shape[0]), dtype=np.float32)

    for idx, label in enumerate(labels):
        hyperedge[label][idx] = 1

    return hyperedge


def k_hop_hyperedge(adj_mx, k, num_centroids):
    n = adj_mx.shape[0]

    H_matrix = np.zeros((num_centroids, n), dtype=np.int32)

    if n == 0:
        return H_matrix

    all_nodes = np.arange(n)
    if num_centroids >= n:
        sampled_centroids = all_nodes.copy()
    else:
        sampled_centroids = np.random.choice(all_nodes, size=num_centroids, replace=False)

    neighbors = [np.where(adj_mx[i] > 0)[0] for i in range(n)]

    for i, center in enumerate(sampled_centroids):

        hyperedge_nodes = {center}

        queue = deque()
        queue.append((center, 0))

        visited = {center}

        while queue:
            current_node, hops = queue.popleft()
            if hops < k:
                for neighbor in neighbors[current_node]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        hyperedge_nodes.add(neighbor)
                        queue.append((neighbor, hops + 1))

        H_matrix[i, list(hyperedge_nodes)] = 1

    return H_matrix


def loadData(filepath, logger, train_ratio=0.6, test_ratio=0.2, bs=16, seq_len=12, horizon=12, tod=96, dow=7):
    # Traffic
    Traffic = np.load(filepath)['data'][..., :1]
    num_step = Traffic.shape[0]

    # temporal positions
    TE = np.zeros([num_step, 2])
    TE[:, 0] = np.array([i % tod for i in range(num_step)])
    TE[:, 1] = np.array([(i // tod) % dow for i in range(num_step)])
    TE_tile = np.repeat(np.expand_dims(TE, 1), Traffic.shape[1], 1)

    Traffic = np.concatenate((Traffic, TE_tile), axis=-1)

    logger.info('Traffic shape: {}'.format(Traffic.shape))

    # train/val/test
    train_steps = round(train_ratio * num_step)
    test_steps = round(test_ratio * num_step)
    val_steps = num_step - train_steps - test_steps

    trainData = Traffic[: train_steps]
    valData = Traffic[train_steps: train_steps + val_steps]
    testData = Traffic[-test_steps:]

    train_ds = TSDataset(trainData, seq_len, horizon, stride=1)
    val_ds = TSDataset(valData, seq_len, horizon, stride=1)
    test_ds = TSDataset(testData, seq_len, horizon, stride=1)

    train_loader = DataLoader(train_ds, batch_size=bs, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=bs, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=bs, shuffle=False)

    # normalization
    mean, std = np.mean(trainData[..., 0]), np.std(trainData[..., 0])
    scaler = StandardScaler(mean, std)

    # log
    logger.info(f'Train samples: {len(train_ds)}, Val samples: {len(val_ds)}, Test samples: {len(test_ds)}')
    logger.info(f'Mean: {mean} & Std: {std}')

    return train_loader, val_loader, test_loader, scaler

