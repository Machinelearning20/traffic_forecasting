import torch
from torch import nn
import torch.nn.functional as F
import math
import numpy as np


def squash(x, epsilon=1e-7):
    norm = torch.norm(x, p=2, dim=-1, keepdim=True)
    scale = (norm ** 2) / (1 + norm ** 2)
    direction = x / (norm + epsilon)
    return scale * direction


class FeedForward(nn.Module):
    def __init__(self, feature_dim):
        super().__init__()
        hidden_dim = feature_dim * 2
        self.fc1 = nn.Linear(in_features=feature_dim, out_features=hidden_dim)
        self.fc2 = nn.Linear(in_features=hidden_dim, out_features=feature_dim)
        self.act = nn.ReLU()
        self.drop = nn.Dropout(p=0.2)

    def forward(self, input_data):
        # input_data: [B, N, C]
        hidden = self.fc2(self.drop(self.act(self.fc1(input_data))))
        hidden = hidden + input_data

        return hidden


class TemporalAggregationMixer(nn.Module):
    def __init__(self, p, d_in, d_out, h, activation=F.relu):
        super().__init__()
        self.p = p
        self.d_in = d_in
        self.d_out = d_out
        self.h = h
        self.activation = activation

        self.mlp1_fc1 = nn.Linear(p * d_in, h)
        self.mlp1_fc2 = nn.Linear(h, d_out)
        self.mlp2_fc1 = nn.Linear(p * d_in, h)
        self.mlp2_fc2 = nn.Linear(h, d_out)

    def forward(self, x):
        batch_size, N, T_prev, d = x.shape
        assert T_prev % self.p == 0
        T_new = T_prev // self.p

        x_window = x.view(batch_size, N, T_new, self.p, d)
        x_flat = x_window.reshape(batch_size, N, T_new, -1)   # (batch_size, N, T_new, p*d)

        h1 = self.mlp1_fc1(x_flat)
        h1 = self.activation(h1)
        h1 = self.mlp1_fc2(h1)  # (batch_size, N, T_new, d)
        h2 = self.mlp2_fc1(x_flat)
        h2 = self.activation(h2)
        h2 = self.mlp2_fc2(h2)  # (batch_size, N, T_new, d)
        output = torch.tanh(h1) * torch.sigmoid(h2)

        return output


class MultiLayerTemporalAggregator(nn.Module):
    def __init__(self, layer_configs: list[dict]):
        super().__init__()
        self.layers = nn.ModuleList([
            TemporalAggregationMixer(
                p=config['p'],
                d_in=config['d_in'],
                d_out=config['d_out'],
                h=config['h']
            ) for config in layer_configs
        ])

    def forward(self, x):
        x_list = []
        for layer in self.layers:
            x = layer(x)
            x_list.append(x[:, :, -1])
        return torch.cat(x_list, dim=-1)


class GraphConvolutional(nn.Module):
    def __init__(self, input_dim, output_dim, order=1):
        super(GraphConvolutional, self).__init__()
        c_hidden = (order + 1) * input_dim
        self.fc_out = nn.Linear(c_hidden, output_dim)
        self.dropout = nn.Dropout(p=0.1)
        self.order = order

    def gconv(self, x, adj):
        x = torch.einsum('bnc,nm->bmc', (x, adj))
        return x.contiguous()

    def forward(self, x, adj):
        # x: [B, N, C]
        out = [x]

        x1 = self.gconv(x, adj)
        out.append(x1)
        for k in range(2, self.order + 1):
            x2 = self.gconv(x1, adj)
            out.append(x2)
            x1 = x2

        h = torch.cat(out, dim=-1)
        h = self.fc_out(h)
        h = self.dropout(h)

        return h


class HyperGraphConvolutional(nn.Module):
    def __init__(self, hidden_dim, support_len=1):
        super(HyperGraphConvolutional, self).__init__()
        self.x_proj = nn.ModuleList(
            [nn.Linear(hidden_dim, hidden_dim) for _ in range(support_len)]
        )
        # self.hyper_mixed = nn.ModuleList([nn.Linear(hidden_dim, hidden_dim) for _ in range(support_len)])
        self.res_proj = nn.Linear((support_len + 1) * hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(p=0.1)

    def forward(self, x, nodevecs):
        # x: [B, N, C]
        out = [x]

        for i, nodevec in enumerate(nodevecs):
            x1 = squash(self.x_proj[i](x))
            hidden = torch.einsum('bnm, bnd->bmd', nodevec, x1)
            hidden = squash(hidden)
            hidden = torch.relu(torch.einsum("bmd, bnm->bnd", hidden, nodevec))
            out.append(hidden)

        h = torch.cat(out, dim=-1)
        h = self.res_proj(h)
        h = self.dropout(h)

        return h


class DynamicHypergraphStructureLearning(nn.Module):
    def __init__(self, dim, node_num, num_hyperedge, k, gate=True):
        super().__init__()
        self.dim = dim
        self.num_hyperedge = num_hyperedge
        self.node_num = node_num
        self.gate = gate
        self.k = k

        if self.gate:
            self.z_projection = nn.Linear(dim, dim)
            self.act = nn.Sigmoid()

        self.hyperedge = nn.Parameter(torch.empty(num_hyperedge, dim), requires_grad=True)
        nn.init.xavier_uniform_(self.hyperedge)

        self.x_proj = nn.Linear(dim, dim)
        self.hyper_proj = nn.Linear(dim, dim)
        self.g_conv = HyperGraphConvolutional(dim, support_len=1)

    def forward(self, x, external_mx):
        original_input = x

        if self.gate:
            z = self.act(self.z_projection(x))

        batch_size, num_nodes, _ = x.shape

        query = self.x_proj(x)
        hyperedge = self.hyperedge.unsqueeze(0).repeat(batch_size, 1, 1)
        key = self.hyper_proj(hyperedge)
        attn_score = (query @ key.transpose(-1, -2)) / self.dim ** 0.5

        if external_mx is not None:
            support = [external_mx.unsqueeze(0).repeat(batch_size, 1, 1)]
        elif self.k != 0:
            topk_values, topk_indices = torch.topk(attn_score, k=self.k, dim=-1)
            topk_attn = torch.softmax(topk_values, dim=-1)
            sparse_attn_score = torch.zeros_like(attn_score)
            sparse_attn_score.scatter_(dim=-1, index=topk_indices, src=topk_attn)
            support = [sparse_attn_score]
        else:
            support = [torch.softmax(attn_score, dim=-1)]

        out = self.g_conv(x, support)

        if self.gate:
            out = out * z

        out = out + original_input

        return out

class SSE(nn.Module):
    def __init__(self, p=0.2):
        """
        Args:
            p (float): Replacement probability, value range [0, 1]. The larger p is, the more frequent the replacement is.
        """
        super(SSE, self).__init__()
        self.p = p

    def forward(self, embeddings, epoch):
        """
        Args:
            embeddings (Tensor): embedding matrix of shape [N, C]
        Returns:
            Tensor: The embedding matrix after applying SSE regularization.
        """
        # If in evaluation mode or p is 0, the original embeddings are returned directly.
        if not self.training or self.p == 0:
            return embeddings

        # SD 30 0.05 37 0.01
        # GBA 33 0.05 37 0.01
        # GLA 30 0.05 37 0.01
        # CA ??
        if epoch == 30:
            self.p = 0.05
        if epoch == 37:
            self.p = 0.01

        N, C = embeddings.shape

        # Generate a Bernoulli mask for each node to decide whether to replace it
        mask = torch.rand(N, device=embeddings.device) < self.p

        # Generate a random index for each node to replace
        random_indices = torch.randint(0, N, (N,), device=embeddings.device)

        # If mask is True, replace it with a randomly selected embedding, otherwise keep the original value
        mask = mask.unsqueeze(1)  # [N, 1]
        sse_embeddings = torch.where(mask, embeddings[random_indices], embeddings)

        return sse_embeddings


class DyHSTA(nn.Module):
    def __init__(self, num_nodes, hyper_mx, adj_mx, args):
        super().__init__()

        # attributes
        self.args = args
        self.num_nodes = num_nodes

        self.spatial_dim = args.spatial_dim
        self.input_len = args.input_len
        self.input_dim = args.input_dim
        self.output_dim = args.output_dim
        self.embed_dim = args.embed_dim
        self.pred_len = args.pred_len
        self.num_layer = args.num_layer
        self.temp_dim_tid = args.temp_dim_tid
        self.temp_dim_diw = args.temp_dim_diw
        self.time_of_day_size = args.time_of_day_size
        self.day_of_week_size = args.day_of_week_size
        self.num_hyperedge = args.num_hyperedge
        self.k = args.k  # TopK's
        self.t_layer = 2

        # external matrix
        self.static_hyper_mx = hyper_mx
        self.adj_mx = adj_mx

        # ablation attributes
        self.if_time = args.if_time
        self.if_gcn = args.if_gcn
        self.if_agcn = args.if_agcn

        # spatial embeddings
        self.node_emb = nn.Parameter(torch.empty(self.num_nodes, self.spatial_dim))
        nn.init.xavier_uniform_(self.node_emb)

        # self.time_series_emb_layer = nn.Linear(in_features=self.input_dim, out_features=self.embed_dim)

        if args.if_sse:
            self.sse = SSE(p=args.p)
        else:
            self.sse = nn.Identity()

        # temporal embeddings
        self.time_in_day_emb = nn.Parameter(
            torch.empty(self.time_of_day_size, self.temp_dim_tid))
        nn.init.xavier_uniform_(self.time_in_day_emb)
        self.day_in_week_emb = nn.Parameter(
            torch.empty(self.day_of_week_size, self.temp_dim_diw))
        nn.init.xavier_uniform_(self.day_in_week_emb)

        self.hidden_dim = self.spatial_dim + self.temp_dim_tid + self.temp_dim_diw + self.embed_dim*self.t_layer

        self.feed_forwards = nn.ModuleList()
        self.gconvs = nn.ModuleList()

        for _ in range(self.num_layer):
            self.feed_forwards.append(FeedForward(self.hidden_dim))
            if self.if_gcn or self.if_agcn:
                self.gconvs.append(GraphConvolutional(self.hidden_dim, self.hidden_dim))
            else:
                self.gconvs.append(DynamicHypergraphStructureLearning(self.hidden_dim, self.num_nodes, self.num_hyperedge, self.k))

        self.regression_layer = nn.Linear(in_features=self.hidden_dim, out_features=self.pred_len)
        self.regression_skip = nn.Linear(in_features=self.hidden_dim, out_features=self.pred_len)

        if self.if_time:
            self.time_module = MultiLayerTemporalAggregator([
                {'p': 6, 'd_in': 1, 'd_out': 32, 'h': 64},
                {'p': 2, 'd_in': 32, 'd_out': 32, 'h': 64}
            ])
        else:
            self.time_series_emb_layer = nn.Linear(in_features=self.input_dim * self.input_len,
                                                   out_features=self.embed_dim)

        self.fuse = nn.Linear(in_features=self.embed_dim*self.t_layer, out_features=self.spatial_dim)

    def forward(self, history_data, epoch=None):
        # history_data: [B, T, N, C]

        # prepare data
        input_data = history_data[..., range(self.input_dim)]
        batch_size, steps, num_nodes, _ = input_data.shape

        # time in day
        t_i_d_data = history_data[..., -2]
        # day of week
        d_i_w_data = history_data[..., -1]

        if self.if_time:
            time_series_emb = self.time_module(input_data.transpose(1, 2)).squeeze(2)
        else:
            input_data = input_data.transpose(1, 2).contiguous()
            input_data = input_data.view(batch_size, num_nodes, -1)
            time_series_emb = self.time_series_emb_layer(input_data)

        if self.if_gcn:
            adj_mx = self.adj_mx
        elif self.if_agcn:
            node_emb = self.node_emb
            adj_mx = F.softmax(F.relu(torch.mm(node_emb, node_emb.T)), dim=1)
        else:
            adj_mx = None

        node_emb = []
        stochastic_shared_node_emb = self.sse(self.node_emb, epoch)
        stochastic_shared_node_emb = stochastic_shared_node_emb.unsqueeze(0).expand(batch_size, -1, -1) * self.fuse(time_series_emb)
        node_emb.append(stochastic_shared_node_emb)

        tem_emb_node = []
        time_in_day_emb = self.time_in_day_emb[(t_i_d_data[:, -1, 0:1]).type(torch.LongTensor)]
        tem_emb_node.append(time_in_day_emb.expand(batch_size, self.num_nodes, -1))
        day_in_week_emb = self.day_in_week_emb[(d_i_w_data[:, -1, 0:1]).type(torch.LongTensor)]
        tem_emb_node.append(day_in_week_emb.expand(batch_size, self.num_nodes, -1))

        # concate all embeddings
        skips = 0.
        hidden = torch.cat([time_series_emb] + node_emb + tem_emb_node, dim=-1)

        for i in range(self.num_layer):
            hidden = self.feed_forwards[i](hidden)
            if self.if_gcn or self.if_agcn:
                hidden = self.gconvs[i](hidden, adj_mx)
            else:
                hidden = self.gconvs[i](hidden, self.static_hyper_mx)
            skips += hidden

        res_regression = self.regression_layer(hidden)
        smooth_regression = self.regression_skip(skips)
        regression = res_regression + smooth_regression
        prediction = regression.transpose(1, 2).contiguous().unsqueeze(-1)  # [B, T, N, C]

        return prediction
