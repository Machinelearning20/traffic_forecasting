import os
import torch
import argparse
import time
import random
import numpy as np

from lib.dataloader import loadData
from lib.dataloader import agglomerative_clustering_hyperedge, kdtree_hyperedge
from lib.logger import get_logger
from lib.trainer import Trainer
from models.DyHSTA import DyHSTA
from tqdm import tqdm

parser = argparse.ArgumentParser()
parser.add_argument('--device', type=str, default='cuda:0', help='')
parser.add_argument('--dataset', type=str, default='GBA', help='dataset name')
parser.add_argument('--batch_size', type=int, default=16, help='batch size')
parser.add_argument('--lrate', type=float, default=0.001, help='learning rate')
parser.add_argument('--wdecay', type=float, default=0.0001, help='weight decay rate')
parser.add_argument('--epochs', type=int, default=50, help='')
parser.add_argument('--start_epoch', type=int, default=0, help='')
parser.add_argument('--seed', type=int, default=1, help='')

parser.add_argument('--input_len', type=int, default=12, help='')
parser.add_argument('--pred_len', type=int, default=12, help='')
parser.add_argument('--num_nodes', type=int, default=2352, help='number of nodes')
parser.add_argument('--spatial_dim', type=int, default=64)
parser.add_argument('--input_dim', type=int, default=1)
parser.add_argument('--output_dim', type=int, default=1)
parser.add_argument('--embed_dim', type=int, default=32)
parser.add_argument('--num_layer', type=int, default=5)
parser.add_argument('--temp_dim_tid', type=int, default=32)
parser.add_argument('--temp_dim_diw', type=int, default=32)
parser.add_argument('--time_of_day_size', type=int, default=96)
parser.add_argument('--day_of_week_size', type=int, default=7)

parser.add_argument('--p', type=float, default=0.1, help='Initial replacement probability for SSE')
parser.add_argument('--num_hyperedge', type=int, default=128)
parser.add_argument('--k', type=int, default=40, help='Top-k attention neighbors per node')

# ablation attributes
parser.add_argument('--if_agg_hyperedge', action='store_true', default=False)
parser.add_argument('--if_kdt_hyperedge', action='store_true', default=False)  # 默认False
parser.add_argument('--if_gcn', action='store_true', default=False)
parser.add_argument('--if_agcn', action='store_true', default=False)
parser.add_argument('--if_time', action='store_false', default=True)
parser.add_argument('--if_sse', action='store_false', default=True)  # 默认True，加 --if_time 变 False

args = parser.parse_args()

device = torch.device(args.device)
logger = get_logger('./log', __name__, 'train_%s.log' % args.dataset)

data_pth = './data/%s/flow.npz' % args.dataset
meta_pth = './data/%s/meta.csv' % args.dataset
adj_pth = './data/%s/rn_adj.npy' % args.dataset

if args.if_agg_hyperedge:
    hyper_mx = agglomerative_clustering_hyperedge(meta_pth, n_clusters=args.num_hyperedge)
    hyper_mx = torch.from_numpy(hyper_mx).to(device).transpose(0, 1)
elif args.if_kdt_hyperedge:
    if args.dataset == 'SD':
        hyper_mx = kdtree_hyperedge(meta_pth, depth=9, factors=32)
    elif args.dataset == 'GBA':
        hyper_mx = kdtree_hyperedge(meta_pth, depth=11, factors=32)
    elif args.dataset == 'GLA':
        hyper_mx = kdtree_hyperedge(meta_pth, depth=11, factors=32)
    else:
        hyper_mx = kdtree_hyperedge(meta_pth, depth=12, factors=8)
    hyper_mx = torch.from_numpy(hyper_mx).float().to(device).transpose(0, 1)
else:
    hyper_mx = None

if args.if_gcn:
    adj_mx = np.load(adj_pth).astype(np.float32)
    adj_mx = torch.from_numpy(adj_mx).to(device)
else:
    adj_mx = None

train_loader, val_loader, test_loader, scaler = loadData(data_pth, logger)

model = DyHSTA(args.num_nodes, hyper_mx, adj_mx, args).to(device)

'''
                sd         gba         gla         ca
    lr_steps  [25, 40]    [30, 40]    [25, 40]
'''
engine = Trainer(model, scaler, device, lrate=args.lrate, wdecay=args.wdecay, if_lr_scheduler=True,
                 lr_steps=[30, 40], lr_decay_ratio=0.1, clip_grad=5)


def main():

    # if args.seed is not None:
    #     random.seed(args.seed)
    #     np.random.seed(args.seed)
    #     torch.manual_seed(args.seed)
    #     torch.cuda.manual_seed(args.seed)
    #     torch.backends.cudnn.deterministic = True

    engine.reset_lr_model(args)

    logger.info("start training...")
    engine.print_model(logger)

    if args.start_epoch > 0:
        engine.reset_lr_model(args)

    best_val_loss = float('inf')
    best_epoch = 0

    for epoch in tqdm(range(args.start_epoch, args.epochs)):
        start = time.time()

        train_loss, train_mape, train_rmse = engine.train(train_loader, epoch=epoch, logger=logger)
        end = time.time()
        logger.info('Training - epoch %d, lr: %.8f Training Time: %.2fs, mae: %.4f, mape: %.4f, rmse: %.4f'
                    % (epoch, engine.optimizer.param_groups[0]['lr'], end - start, train_loss, train_mape, train_rmse))

        start = time.time()
        val_mae, val_mape, val_rmse = engine.eval(val_loader)
        end = time.time()

        logger.info('Validation - epoch %d Validation Time: %.2fs, mae: %.4f, mape: %.4f, rmse: %.4f'
                    % (epoch, end - start, val_mae, val_mape, val_rmse))

        if val_mae < best_val_loss:
            best_val_loss = val_mae
            best_epoch = epoch

            save_path = f'cpt/{args.dataset}/best_model.pth'
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            torch.save({
                'model_state_dict': engine.model.state_dict(),
                'optimizer_state_dict': engine.optimizer.state_dict(),
                'lr_scheduler_state_dict': engine.lr_scheduler.state_dict() if engine.lr_scheduler is not None else None,
            }, save_path)

            logger.info(f'Saved best model at epoch {epoch} with validation MAE: {val_mae:.4f}')

    test(engine, test_loader, best_epoch, logger)


def test(engine, data_loader, best_epoch, logger):
    checkpoint = torch.load(f'cpt/{args.dataset}/best_model.pth')
    engine.model.load_state_dict(checkpoint['model_state_dict'])
    logger.info("start testing...")
    logger.info('Best epoch: %d' % best_epoch)
    engine.test(data_loader, best_epoch, logger)


if __name__ == "__main__":
    main()
    # test(engine, test_loader, 44, logger)