This is a PyTorch implementation of the paper: "DYNAMIC HYPERGRAPH SPATIOTEMPORAL AGGREGATION NETWORK FOR LARGE-SCALE TRAFFIC FORECASTING".

## 1. Repo Structure

```
LargeScaleFS/
├── main.py                  # This is the main file for training and testing
├── lib/
│   ├── dataloader.py        # Codes of preprocessing datasets and calculating metrics
│   ├── trainer.py           # Train / validation / test loops
│   ├── metrics.py           # masked MAE / RMSE / MAPE and the numpy evaluation metric
│   ├── logger.py            # Logger that writes to both file and console
│   └── vis.py               # Visualization helpers
├── models/
│   └── DyHSTA.py            # The core source code of our DyHSTA
├── data/                    # Datasets (NOT tracked by git, see Section 3)
│   └── <DS>/                #   SD / GBA / GLA / CA, each with flow.npz, meta.csv, rn_adj.npy
├── cpt/                     # checkpoints, best_model.pth per dataset
└── log/                     # training logs, train_<DS>.log
```

The model takes the past 12 steps (3 hours at 15-minute granularity) of network-wide traffic flow and predicts the next 12 steps, evaluated with MAE / RMSE / MAPE.

## 2. Requirements

Main dependencies:

- Python >= 3.8
- PyTorch >= 1.12
- NumPy
- Pandas
- scikit-learn
- tqdm

## 3. Data Preparation

We follow [LargeST](https://github.com/liuxu77/LargeST) to prepare data. Please follow the data preparation instructions of LargeST strictly. Note that the data does not need to be normalized in advance, since normalization is handled inside `lib/dataloader.py` at runtime. All the four sub-datasets
utilize traffic sensor data from the entire year of 2019.

## 4. Model Training

Run the following commands to train and evaluate DyHSTA on the four datasets.

```bash
python main.py --dataset=SD --num_hyperedge=16 --num_nodes=716 --num_layer=3 --k=10
python main.py --dataset=GBA --num_hyperedge=128 --num_nodes=2352 --num_layer=5 --k=30
python main.py --dataset=GLA --num_hyperedge=256 --num_nodes=3834 --num_layer=5 --k=20
python main.py --dataset=CA --num_hyperedge=512 --num_nodes=8600 --num_layer=6 --k=30
```

Key arguments:

- `--dataset` — one of `SD`, `GBA`, `GLA`, `CA`; also selects `data/<DS>/`, `cpt/<DS>/` and `log/train_<DS>.log`.
- `--num_nodes` — number of sensors, must match the dataset (716 / 2352 / 3834 / 8600).
- `--num_hyperedge` — number of hyperedges, scaled with the network size (16 → 512).
- `--num_layer` — number of stacked DyHSTA blocks.
- `--k` — number of top-k hyperedge neighbours each node attends to.
